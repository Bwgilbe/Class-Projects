
public class slim_poke {

    public static void main(String[] args) {
        // TODO code application logic here
        slime pudding = new slime("Pudding");
        slime tofu = new slime("tofu");
        //slime pudding.status();

        tofu.getPoke(pudding.poke());
        tofu.getPoke(pudding.SuperPoke());
        tofu.getPoke(pudding.SuperPoke());
    }

}
